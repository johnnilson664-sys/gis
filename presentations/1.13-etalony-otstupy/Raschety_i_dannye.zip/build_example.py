#!/usr/bin/env python3
"""Deterministic teaching example: SYN-flood prototypes and linear soft-margin SVM.

All observations are manually constructed. The held-out set illustrates decisions;
it is not an independent benchmark and must not be used to claim deployment quality.
Run: python /workspace/work/numerical/build_example.py
"""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mplconfig"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import sklearn
from sklearn.svm import SVC

NAVY, TEAL, RED, GOLD, BG = "#101C32", "#008C95", "#E85555", "#E5B64A", "#F4F7FA"
COLORS = {-1: TEAL, 1: RED}
CLASS_NAMES = {-1: "норма", 1: "SYN-flood"}
TAU = 0.1

# Fixed engineering scales, not fitted normalization: x1=SYN/s/1000; x2=ratio.
# Each row represents a 10-second window on the same service.
TRAIN = [
    ("N01", .20, .05, -1, "обычный фон"),
    ("N02", .32, .08, -1, "обычный фон"),
    ("N03", .45, .10, -1, "обычная нагрузка"),
    ("N04", .55, .08, -1, "обычная нагрузка"),
    ("N05", .60, .15, -1, "обычная нагрузка"),
    ("N06", .72, .12, -1, "повышенная легитимная нагрузка"),
    ("N07", .85, .18, -1, "повышенная легитимная нагрузка"),
    ("N08", 1.05, .15, -1, "легитимный всплеск SYN"),
    ("N09", .92, .30, -1, "легитимная нагрузка с потерями"),
    ("N10", .75, .40, -1, "легитимная нагрузка с потерями"),
    ("A01", 1.05, .65, 1, "SYN-flood"),
    ("A02", 1.20, .75, 1, "SYN-flood"),
    ("A03", 1.40, .82, 1, "SYN-flood"),
    ("A04", 1.60, .90, 1, "SYN-flood"),
    ("A05", 1.80, .92, 1, "SYN-flood"),
    ("A06", 1.30, .65, 1, "SYN-flood"),
    ("A07", 1.50, .75, 1, "SYN-flood"),
    ("A08", .95, .60, 1, "SYN-flood умеренной интенсивности"),
    ("A09", 1.10, .50, 1, "SYN-flood после частичного ограничения"),
    ("A10", .80, .56, 1, "SYN-flood умеренной интенсивности"),
]
TEST = [
    ("T01", .42, .09, -1, "обычная нагрузка"),
    ("T02", 1.55, .88, 1, "выраженный SYN-flood"),
    ("T03", .95, .40, -1, "пограничный легитимный всплеск"),
    ("T04", .90, .40, 1, "пограничный SYN-flood"),
    ("T05", 1.00, .42, -1, "пограничная легитимная нагрузка с потерями"),
    ("T06", .95, .46, 1, "пограничный SYN-flood"),
    ("T07", 1.20, .16, -1, "легитимный всплеск с успешными рукопожатиями"),
    ("T08", .95, .75, 1, "SYN-flood умеренной интенсивности"),
]


def unpack(rows):
    return np.array([[r[1], r[2]] for r in rows]), np.array([r[3] for r in rows])


def medoid(rows, label):
    selected = sorted([r for r in rows if r[3] == label], key=lambda r: r[0])
    X, _ = unpack(selected)
    totals = np.linalg.norm(X[:, None, :] - X[None, :, :], axis=2).sum(axis=1)
    min_total = totals.min()
    # Lexicographic ID tie break within floating-point tolerance.
    idx = next(i for i, total in enumerate(totals) if np.isclose(total, min_total, rtol=0, atol=1e-12))
    row = selected[idx]
    return {"id": row[0], "x": [row[1], row[2]], "y": label,
            "sum_within_class_distances": float(totals[idx]),
            "candidate_sums": {r[0]: float(t) for r, t in zip(selected, totals)}}


def records(rows, model, prototypes):
    X, y = unpack(rows)
    f = model.decision_function(X)
    yhat = model.predict(X)
    wnorm = np.linalg.norm(model.coef_[0])
    output = []
    for row, fx, predicted in zip(rows, f, yhat):
        ident, x1, x2, label, note = row
        dn = float(np.linalg.norm(np.array([x1, x2]) - prototypes[-1]["x"]))
        da = float(np.linalg.norm(np.array([x1, x2]) - prototypes[1]["x"]))
        score_difference = dn - da  # s_attack - s_normal; each score = -distance.
        if abs(score_difference) < 1e-12:
            score_difference = 0.0
        ref_pred = 1 if score_difference > 0 else -1  # tie rule: normal, flagged below.
        functional_margin = float(label * fx)
        geom_margin = functional_margin / wnorm
        dist = abs(float(fx)) / wnorm
        output.append({
            "id": ident, "x1_syn_per_1000": x1, "x2_unfinished_ratio": x2,
            "syn_per_second": x1 * 1000, "y": label, "class_ru": CLASS_NAMES[label],
            "note_ru": note, "distance_to_normal_medoid": dn,
            "distance_to_attack_medoid": da,
            "score_normal": -dn, "score_attack": -da,
            "prototype_margin_y_score_diff": float(label * score_difference),
            "prototype_prediction": ref_pred, "prototype_tie": score_difference == 0,
            "f": float(fx), "prediction": int(predicted),
            "correct": bool(label == predicted),
            "functional_margin_yf": functional_margin,
            "labelled_geometric_margin": float(geom_margin),
            "distance_to_boundary": float(dist),
            "hinge_slack": float(max(0.0, 1 - functional_margin)),
            "review_abs_distance_lt_tau": bool(dist < TAU),
        })
    return output


def write_csv(name, rows):
    with (ROOT / name).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def configure_plotting():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 12,
        "text.color": NAVY, "axes.labelcolor": NAVY, "axes.edgecolor": "#CDD6DF",
        "xtick.color": NAVY, "ytick.color": NAVY, "figure.facecolor": BG,
        "axes.facecolor": BG, "svg.fonttype": "none", "axes.spines.top": False,
        "axes.spines.right": False, "grid.color": "#DCE3EA", "grid.alpha": .6,
    })


def format_axis(ax, xlim=(0.1, 1.9), ylim=(0, 1)):
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_xlabel("$x_1$: входящие SYN/с ÷ 1000", labelpad=12)
    ax.set_ylabel("$x_2$: доля незавершённых рукопожатий", labelpad=12)
    ax.grid(True)
    ax.set_axisbelow(True)
    ax.set_aspect("equal", adjustable="box")


def save_figure(fig, basename):
    fig.savefig(ROOT / f"{basename}.png", dpi=160, facecolor=BG)
    fig.savefig(ROOT / f"{basename}.svg", facecolor=BG)
    plt.close(fig)


def prototype_figure(train, test, prototypes):
    fig = plt.figure(figsize=(16, 9))
    ax = fig.add_axes([.075, .18, .57, .64])
    side = fig.add_axes([.70, .18, .27, .64])
    side.axis("off")
    fig.text(.075, .925, "Эталон класса — его типичный наблюдаемый объект", fontsize=24, weight="bold")
    fig.text(.075, .878, "Медоиды выбраны только по 20 обучающим окнам; метрика — евклидова в фиксированном масштабе.", fontsize=13)
    X, y = unpack(TRAIN)
    for label, marker in [(-1, "o"), (1, "s")]:
        mask = y == label
        ax.scatter(X[mask, 0], X[mask, 1], c=COLORS[label], marker=marker, s=65,
                   alpha=.45, edgecolors="white", linewidths=.8,
                   label="Train: " + CLASS_NAMES[label])
        p = prototypes[label]
        ax.scatter(*p["x"], marker="*", c=COLORS[label], s=520, edgecolors=NAVY,
                   linewidths=1.3, zorder=5)
    pn, pa = np.array(prototypes[-1]["x"]), np.array(prototypes[1]["x"])
    ax.annotate("N05 · эталон нормы\n(0,60; 0,15)", pn, xytext=(.19, .23),
                color=TEAL, fontsize=12, weight="bold",
                arrowprops={"arrowstyle": "-", "color": TEAL})
    ax.annotate("A06 · эталон SYN-flood\n(1,30; 0,65)", pa, xytext=(1.10, .78),
                color=RED, fontsize=12, weight="bold",
                arrowprops={"arrowstyle": "-", "color": RED})
    obj = next(r for r in test if r["id"] == "T04")
    x = np.array([obj["x1_syn_per_1000"], obj["x2_unfinished_ratio"]])
    ax.plot([x[0], pn[0]], [x[1], pn[1]], color=TEAL, linewidth=2.5, zorder=3)
    ax.plot([x[0], pa[0]], [x[1], pa[1]], color=RED, linewidth=2.5, zorder=3)
    ax.scatter(*x, marker="D", s=180, c=GOLD, edgecolors=NAVY, linewidths=1.5, zorder=6)
    ax.annotate("T04 · истинный класс: атака", x, xytext=(.29, .53),
                fontsize=12, weight="bold", arrowprops={"arrowstyle": "->", "color": NAVY})
    ax.text(.66, .245, "$d_N=0{,}3905$", color=TEAL, fontsize=13,
            bbox={"facecolor": BG, "edgecolor": "none", "pad": 2})
    ax.text(1.03, .48, "$d_A=0{,}4717$", color=RED, fontsize=13,
            bbox={"facecolor": BG, "edgecolor": "none", "pad": 2})
    # Equal-distance locus; squared distances give a straight bisector.
    gx = np.linspace(.1, 1.9, 300)
    gy = (.865 - .7 * gx) / .5
    ax.plot(gx, gy, "--", color=NAVY, alpha=.55, linewidth=1.5, label="Равные расстояния до эталонов")
    format_axis(ax)
    ax.legend(loc="upper left", frameon=True, facecolor=BG, edgecolor="none", fontsize=10)
    side.text(0, .96, "Отступ эталонной модели", fontsize=18, weight="bold", va="top")
    side.text(0, .84, "Mref = dчужой − dсвой", fontsize=16, va="top")
    side.text(0, .72, "Для T04 свой класс — атака:", fontsize=14, va="top")
    side.text(0, .61, "$M_{ref}=d_N-d_A$", fontsize=16, va="top")
    side.text(0, .51, "$=0{,}3905-0{,}4717$", fontsize=16, va="top")
    side.text(0, .41, "$=−0{,}0812$", fontsize=16, va="top")
    side.text(0, .27, "Отступ отрицателен:\nчужой эталон ближе.\n\nЭталонная модель ошибается\nна этом пограничном объекте.", fontsize=13, linespacing=1.3, va="top")
    fig.text(.075, .075, "Синтетический учебный пример • Эталон — медоид, а не «идеальная» норма • Расстояния зависят от масштаба признаков", fontsize=12, color="#5D6A7C")
    save_figure(fig, "prototype_distances")


def svm_figure(train, test, model):
    fig = plt.figure(figsize=(16, 9))
    ax = fig.add_axes([.075, .19, .57, .63])
    zoom = fig.add_axes([.71, .47, .255, .31])
    note = fig.add_axes([.71, .17, .255, .25])
    note.axis("off")
    fig.text(.075, .925, "SVM: расстояние до границы показывает устойчивость решения", fontsize=21, weight="bold")
    fig.text(.075, .878, "$f(x)=1{,}216667x_1+2{,}116667x_2−2{,}047500$  •  $C=1$  •  зона проверки: $|f(x)|/\\|w\\|<0{,}10$", fontsize=14)
    X, y = unpack(TRAIN)
    w, b = model.coef_[0], float(model.intercept_[0])
    wnorm = float(np.linalg.norm(w))
    gx, gy = np.meshgrid(np.linspace(.1, 1.9, 500), np.linspace(0, 1, 500))
    zz = w[0] * gx + w[1] * gy + b
    ax.contourf(gx, gy, np.abs(zz) / wnorm, levels=[0, TAU], colors=[GOLD], alpha=.23)
    ax.contour(gx, gy, zz, levels=[-1, 0, 1], colors=[TEAL, NAVY, RED],
               linestyles=["--", "-", "--"], linewidths=[1.7, 2.1, 1.7])
    for label, marker in [(-1, "o"), (1, "s")]:
        mask = y == label
        ax.scatter(X[mask, 0], X[mask, 1], c=COLORS[label], marker=marker, s=63,
                   edgecolors="white", linewidths=.8, alpha=.75, zorder=4)
    sv = model.support_vectors_
    ax.scatter(sv[:, 0], sv[:, 1], s=165, facecolors="none", edgecolors=GOLD,
               linewidths=1.9, zorder=5)
    for r in test:
        ax.scatter(r["x1_syn_per_1000"], r["x2_unfinished_ratio"],
                   c=COLORS[r["y"]], marker="D", s=115,
                   edgecolors=NAVY, linewidths=1.3, zorder=7)
        if r["id"] not in {"T03", "T04", "T05", "T06"}:
            ax.annotate(r["id"], (r["x1_syn_per_1000"], r["x2_unfinished_ratio"]),
                        xytext=(8, 7), textcoords="offset points", fontsize=10, weight="bold")
    ax.annotate("T03–T06\nувеличены справа", (.965, .43), xytext=(1.28, .34),
                fontsize=11, arrowprops={"arrowstyle": "->", "color": NAVY})
    ax.text(.27, .60, "$f=-1$", color=TEAL, fontsize=13)
    ax.text(.42, .75, "$f=0$", color=NAVY, fontsize=13)
    ax.text(.67, .92, "$f=+1$", color=RED, fontsize=13)
    format_axis(ax)
    handles = [
        Line2D([], [], marker="o", color="none", markerfacecolor=TEAL, markeredgecolor="white", markersize=8, label="Train: норма"),
        Line2D([], [], marker="s", color="none", markerfacecolor=RED, markeredgecolor="white", markersize=8, label="Train: SYN-flood"),
        Line2D([], [], marker="o", color="none", markerfacecolor="none", markeredgecolor=GOLD, markeredgewidth=2, markersize=11, label="Опорный вектор"),
        Line2D([], [], marker="D", color="none", markerfacecolor=BG, markeredgecolor=NAVY, markersize=8, label="Held-out пример"),
    ]
    ax.legend(handles=handles, loc="lower left", frameon=True, facecolor=BG, edgecolor="none", fontsize=10)
    zoom.set_title("Пограничные тестовые объекты", fontsize=13, loc="left", pad=14, weight="bold")
    zgx, zgy = np.meshgrid(np.linspace(.84, 1.07, 200), np.linspace(.34, .51, 200))
    zzz = w[0]*zgx + w[1]*zgy + b
    zoom.contourf(zgx, zgy, np.abs(zzz) / wnorm, levels=[0, TAU], colors=[GOLD], alpha=.23)
    zoom.contour(zgx, zgy, zzz, levels=[0], colors=[NAVY], linewidths=1.8)
    offsets = {"T03": (-12, -25), "T04": (-29, 10), "T05": (8, -10), "T06": (8, 8)}
    for r in test:
        if r["id"] in offsets:
            xx, yy = r["x1_syn_per_1000"], r["x2_unfinished_ratio"]
            zoom.scatter(xx, yy, c=COLORS[r["y"]], marker="D", s=105,
                         edgecolors=NAVY, linewidths=1.3, zorder=7)
            label = r["id"] + (" ×" if not r["correct"] else "")
            zoom.annotate(label, (xx, yy), xytext=offsets[r["id"]], textcoords="offset points",
                          fontsize=11, weight="bold")
    zoom.set_xlim(.84, 1.07)
    zoom.set_ylim(.34, .51)
    zoom.set_aspect("equal", adjustable="box")
    zoom.grid(True)
    zoom.set_xlabel("$x_1$")
    zoom.set_ylabel("$x_2$")
    zoom.text(.845, .495, "норма", color=TEAL, fontsize=10)
    zoom.text(1.012, .485, "атака", color=RED, fontsize=10)
    lines = ["ID         γ = y f / ‖w‖      решение"]
    for r in test:
        if r["id"] in offsets:
            gamma = f'{r["labelled_geometric_margin"]:+.4f}'.replace(".", ",").replace("-", "−")
            verdict = "верно" if r["correct"] else "ошибка"
            lines.append(f'{r["id"]}       {gamma}           {verdict}')
    note.text(0, 1, "\n".join(lines), va="top", fontsize=12, linespacing=1.7,
              fontfamily="DejaVu Sans Mono")
    note.text(0, .04, "× — ошибочное решение. Цвет — истинный класс.\nγ < 0 означает ошибку; |γ| < 0,10 — проверка.", fontsize=10, linespacing=1.4)
    fig.text(.075, .075, "Все точки синтетические • 8 тестовых окон выбраны для иллюстрации, а не независимой оценки качества • Единицы расстояния заданы масштабом x₁, x₂", fontsize=11, color="#5D6A7C")
    save_figure(fig, "svm_margin")


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    X, y = unpack(TRAIN)
    model = SVC(kernel="linear", C=1.0, tol=1e-10, shrinking=False)
    model.fit(X, y)
    prototypes = {label: medoid(TRAIN, label) for label in [-1, 1]}
    train = records(TRAIN, model, prototypes)
    test = records(TEST, model, prototypes)
    support_ids = [TRAIN[i][0] for i in model.support_]
    for i, row in enumerate(train):
        row["support_vector"] = i in model.support_
    for row in test:
        row["support_vector"] = False
    w = model.coef_[0]
    wnorm = float(np.linalg.norm(w))
    t04 = next(r for r in test if r["id"] == "T04")
    c_sweep = []
    for c_value in [.1, 1.0, 10.0]:
        candidate = SVC(kernel="linear", C=c_value, tol=1e-10, shrinking=False).fit(X, y)
        candidate_norm = float(np.linalg.norm(candidate.coef_[0]))
        train_records = records(TRAIN, candidate, prototypes)
        test_records = records(TEST, candidate, prototypes)
        c_sweep.append({
            "C": c_value, "coef": candidate.coef_[0].tolist(),
            "intercept": float(candidate.intercept_[0]), "norm_w": candidate_norm,
            "full_margin_width": 2 / candidate_norm,
            "half_margin_width": 1 / candidate_norm,
            "support_count": len(candidate.support_),
            "support_ids": [TRAIN[i][0] for i in candidate.support_],
            "train_error_count": sum(not r["correct"] for r in train_records),
            "train_margin_violation_count": sum(r["functional_margin_yf"] < 1-1e-6 for r in train_records),
            "train_hinge_sum": sum(r["hinge_slack"] for r in train_records),
            "train_objective": .5 * candidate_norm**2 + c_value * sum(r["hinge_slack"] for r in train_records),
            "illustrative_error_count": sum(not r["correct"] for r in test_records),
            "illustrative_error_ids": [r["id"] for r in test_records if not r["correct"]],
            "illustrative_review_ids": [r["id"] for r in test_records if r["review_abs_distance_lt_tau"]],
            "illustrative_records": test_records,
        })
    result = {
        "purpose_ru": "Учебная демонстрация эталонов, отступов и мягкого зазора при SYN-flood",
        "provenance": "manually constructed synthetic data; no real traffic; no randomness",
        "window_seconds": 10,
        "measurement_definition_ru": "Неперекрывающиеся окна 10 с на одном сервисе. x1 — среднее число всех входящих SYN-пакетов в секунду /1000; x2 — доля соединений, начатых в окне, без полного TCP-рукопожатия в течение фиксированного тайм-аута 3 с. Для x2 повторы SYN дедуплицируют по попытке соединения. Нужна двунаправленная видимость; измерение ретроспективно после тайм-аута последней попытки.",
        "features": [
            {"name": "x1", "definition": "average incoming SYN packets per second / 1000 over a 10-second window", "units": "fixed scaled units"},
            {"name": "x2", "definition": "fraction of initiated connections without completed handshake within 3 s", "range": [0, 1]},
        ],
        "scaling": "Fixed instructional engineering scale, Euclidean metric; no fitted scaler.",
        "label_encoding": {"-1": "normal traffic", "1": "SYN-flood traffic"},
        "split": {"train_n": len(train), "held_out_illustrative_n": len(test),
                  "warning": "Held-out examples are deliberately chosen illustrations, NOT an independent benchmark. No empirical generalization claim."},
        "prototypes": {str(label): p for label, p in prototypes.items()},
        "prototype_rule": {"medoid": "argmin within-class sum of Euclidean distances; ties by lexicographic ID", "scores": "s_k(x)=-||x-p_k||_2", "margin": "M_ref=d_to_opposite-d_to_own=y*(s_attack-s_normal)", "prediction": "nearest prototype; exact tie predicts -1 and is marked prototype_tie=true"},
        "svm": {
            "package_version": sklearn.__version__, "kernel": "linear", "C": 1.0, "tol": 1e-10,
            "shrinking": False, "C_rationale_ru": "Фиксированный учебный C=1: без подбора по тесту; допускает нарушения отступа для иллюстрации компромисса мягкого зазора.",
            "objective": "min 0.5*||w||^2 + C*sum(xi), s.t. y_i*(w'x_i+b)>=1-xi_i, xi_i>=0",
            "coef": w.tolist(), "intercept": float(model.intercept_[0]), "norm_w": wnorm,
            "half_margin_width": 1 / wnorm, "full_margin_width": 2 / wnorm,
            "support_ids": support_ids, "support_count": len(support_ids),
            "dual_coef": model.dual_coef_[0].tolist(),
            "train_count_margin_inside": sum(0 < r["functional_margin_yf"] < 1-1e-6 for r in train),
            "train_count_margin_violation": sum(r["functional_margin_yf"] < 1-1e-6 for r in train),
            "train_error_count": sum(not r["correct"] for r in train),
            "test_illustrative_error_ids": [r["id"] for r in test if not r["correct"]],
            "test_illustrative_review_ids": [r["id"] for r in test if r["review_abs_distance_lt_tau"]],
            "tau": TAU,
            "functions": {"decision": "f=w'x+b; predict sign(f)", "functional_margin": "m=yf", "labelled_geometric_margin": "gamma=yf/||w||", "distance_to_boundary": "d=|f|/||w||=|gamma|", "hinge_slack": "xi=max(0,1-yf)", "review": "d<tau"},
        },
        "manual_T04": t04,
        "c_sweep": c_sweep,
        "train": train,
        "held_out_illustrative_test": test,
        "interpretation_ru": [
            "Положительный размеченный отступ gamma означает верную классификацию, отрицательный — ошибку; величина d=|gamma| показывает близость к границе.",
            "d — минимальное евклидово изменение x, достигающее границы линейного классификатора при произвольных направлениях возмущения. Это не вероятность атаки и не гарантия устойчивости к любым изменениям исходного трафика.",
            "Отступ эталонной модели M_ref — разность расстояний, а не непосредственно геометрическое расстояние до границы; значения M_ref и gamma нельзя напрямую сравнивать.",
            "Малый d оправдывает проверку или сбор дополнительных признаков; пограничные значения могут возникать при потерях сети и легитимных всплесках.",
            "Только обучающие точки могут быть опорными векторами; тестовый объект с малым отступом не становится опорным вектором.",
        ],
    }
    (ROOT / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv("train.csv", train)
    write_csv("test_illustrative.csv", test)
    configure_plotting()
    prototype_figure(train, test, prototypes)
    svm_figure(train, test, model)
    print(json.dumps({"coef": w.tolist(), "b": float(model.intercept_[0]), "norm_w": wnorm,
                      "prototype_ids": [prototypes[k]["id"] for k in [-1, 1]],
                      "support_ids": support_ids,
                      "test": [{k: r[k] for k in ["id", "y", "f", "prediction", "functional_margin_yf", "labelled_geometric_margin", "distance_to_boundary", "hinge_slack", "prototype_margin_y_score_diff"]} for r in test]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
