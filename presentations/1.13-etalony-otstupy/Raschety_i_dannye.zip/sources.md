# Источники

Проверено16.10.2026. Все численные данные в работе синтетические.

1. [Cortes & Vapnik (1995). Support-vector networks.](https://doi.org/10.1007/BF00994018)

2. [A. Ng, Stanford CS229. Support Vector Machines.](https://see.stanford.edu/materials/aimlcs229/cs229-notes3.pdf)

3. [Schubert & Rousseeuw. Faster k-Medoids Clustering.](https://arxiv.org/abs/1810.05691)

4. [W. Eddy. RFC4987: TCP SYN Flooding Attacks and Common Mitigations.](https://www.rfc-editor.org/rfc/rfc4987.html)

5. [scikit-learn, Support Vector Machines.](https://scikit-learn.org/stable/modules/svm.html)

6. [Moosavi-Dezfooli et al. DeepFool, CVPR2016.](https://www.cv-foundation.org/openaccess/content_cvpr_2016/papers/Moosavi-Dezfooli_DeepFool_A_Simple_CVPR_2016_paper.pdf)

7. [UNB CICDDoS2019 (не использован в расчётах; перспектива проверки).](https://www.unb.ca/cic/datasets/ddos-2019.html)